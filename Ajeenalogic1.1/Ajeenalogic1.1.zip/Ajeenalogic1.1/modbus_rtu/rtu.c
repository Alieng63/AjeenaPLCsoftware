#include <rtu.h>
#include "stdio.h"

#define __HMI_SLAVE_ADD 0x2

//Structure definition for feedback messages
res01_typedef res01;
res03_typedef res03;
res0F_typedef res0F;
res06_typedef res06;

//Structure definition for sent messages
cmd01_typedef cmd01;
cmd03_typedef cmd03;
cmd0F_typedef cmd0F;
cmd06_typedef cmd06;




uint16_t CRC_CAL(uint8_t * data, uint8_t  length){

	int j;
	uint16_t  reg_crc=0Xffff;
	while(length--){
		reg_crc ^= *data++;
		for (j=0;j<8;j++){
			if(reg_crc & 0x01){
				reg_crc=(reg_crc>>1) ^ 0Xa001; /* LSB(b0)=1 */
			}else{reg_crc=reg_crc >>1;}
		}
	}
	return reg_crc;
}

static uint16_t myCRC16;
void RTU_Init(void){





	//cmd01 : read 2 bits 16 17
	cmd01.SlaveAdd =__HMI_SLAVE_ADD;
	cmd01.CMD = 0x1;
	cmd01.Add_H= 0x0;
	cmd01.Add_L= 0x10;
	cmd01.NOP_H= 0x0;
	cmd01.NOP_L = 0x2;

	myCRC16 = CRC_CAL(&cmd01.SlaveAdd,__cmd01_BYTE_CRC);
	cmd01.CRC_L = myCRC16;
	cmd01.CRC_H = myCRC16>>8;


	//cmd03 : read a word 1 $1
	cmd03.SlaveAdd = __HMI_SLAVE_ADD;
	cmd03.CMD = 0x3;
	cmd03.Add_H= 0x0;
	cmd03.Add_L= 0x1;
	cmd03.NOP_H= 0x0;
	cmd03.NOP_L = 0x1;

	myCRC16 = CRC_CAL(&cmd03.SlaveAdd,__CMD03_BYTE_CRC);
	cmd03.CRC_L = myCRC16;
	cmd03.CRC_H = myCRC16>>8;


	//cmd0F : writing to 0 , 1 ( $2000.0 , $2000.1 )
	cmd0F.SlaveAdd = __HMI_SLAVE_ADD;
	cmd0F.CMD = 0xF;
	cmd0F.Add_H= 0x0;
	cmd0F.Add_L= 0x0;
	cmd0F.NOP_H= 0x0;
	cmd0F.NOP_L = 0x2;
	cmd0F.CNT = 0x1;
	cmd0F.Data = 0x0;

	myCRC16 = CRC_CAL(&cmd0F.SlaveAdd,__CMD0F_BYTE_CRC);
	cmd0F.CRC_L = myCRC16;
	cmd0F.CRC_H = myCRC16>>8;


	//cmd06 : writing address 0 $0
	cmd06.SlaveAdd = __HMI_SLAVE_ADD;
	cmd06.CMD = 0x6;
	cmd06.Add_H= 0x0;
	cmd06.Add_L= 0x0;
	cmd06.Data_H = (uint8_t)(ADC1->DR >> 8);
	cmd06.Data_L = (uint8_t)ADC1->DR;


	myCRC16 = CRC_CAL(&cmd06.SlaveAdd,__CMD06_BYTE_CRC);
	cmd06.CRC_L = myCRC16;
	cmd06.CRC_H = myCRC16>>8;
}
