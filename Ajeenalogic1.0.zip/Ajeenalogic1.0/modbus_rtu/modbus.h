#pragma once

//#include <rtu.h>
#include "../../modbus_rtu/rtu.h"
#include "main.h"
#ifdef MODBUS_H
#define MODBUS_H


void MODBUS_Polling(void);
void MODBUS_Init(void);
void MODBUS_Start(void );
void test(void);
#endif

