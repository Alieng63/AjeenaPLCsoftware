//#include "../modbus_rtu/modbus.h"
#include "modbus.h"

#include "stdio.h"

static uint16_t myCRC16;

uint16_t myc0;
uint8_t cmd0F_byte;
uint16_t * CRC16_Ptr;

typedef enum {
	modbus_idle =0,
	modbus_Tx=1,
	modbus_Rx=2
}modbus_status_typedef;

typedef enum{
	Stage_02 = 0,
	Stage_03 = 1,
	Stage_0F = 2,
	Stage_10 = 3
}modbus_stage_Typedef;

modbus_stage_Typedef modbus_stage;
volatile modbus_status_typedef modbus_status;



#define RX_PIN GPIO_PIN_12
#define RX_PORT GPIOB

#define __UART_TX  HAL_GPIO_WritePin(RX_PORT, RX_PIN, (1) ? GPIO_PIN_SET : GPIO_PIN_RESET);

#define __UART_RX  HAL_GPIO_WritePin(RX_PORT, RX_PIN, (0) ? GPIO_PIN_SET : GPIO_PIN_RESET);


void MODBUS_Timeout(void){

	if(modbus_status != modbus_idle ){
		HAL_UART_DMAStop(&huart2);
	}
	MODBUS_Start();



}
void test(void){

	if(cmd0F.Data!=0x1){
		HAL_GPIO_WritePin(nn_PORT, nn_PIN, (1) ? GPIO_PIN_SET : GPIO_PIN_RESET);
	}
	else{
	HAL_GPIO_WritePin(nn_PORT, nn_PIN, (0) ? GPIO_PIN_SET : GPIO_PIN_RESET);
	}




}


void MODBUS_Init(void){
















	//tim4
	RCC->APB1ENR |= RCC_APB1ENR_TIM4EN;

	TIM4->CR1 = 0;

	TIM4->ARR = (uint16_t)49999;
	TIM4->PSC = (uint16_t)359;

	TIM4->SR = ~TIM_SR_UIF;
	TIM4->DIER |= TIM_DIER_UIE;

	X_CallBack_TIM4.UP = MODBUS_Timeout;

	uint32_t PG=NVIC_GetPriorityGrouping();
	NVIC_SetPriority(TIM4_IRQn, NVIC_EncodePriority(PG, 6, 0));
	NVIC_EnableIRQ(TIM4_IRQn);


	TIM4->CR1 |= TIM_CR1_CEN;

}

void LED_Change(uint8_t Data){
	if(Data & 0x1){
		__LED_X0_ON;
	}else{__LED_X0_OFF;}

	if(Data & 0x2){
		__LED_X1_ON;
	}else{__LED_X1_OFF;}
}


void MODBUS_Start(void ){

	//cmd01 : reading X0 to X7
	__UART_TX;
	HAL_UART_Transmit_DMA(&huart2,&cmd01.SlaveAdd, __CMD01_L);
	modbus_status = modbus_Tx;
	modbus_stage = Stage_02;


}

void DeleteParity(uint8_t * byte,uint8_t num){

	for(int i =0 ;i<num;i++){
		byte[i] &= (uint8_t)0x7F;
	}

}

void HAL_UART_TxCpltCallback(UART_HandleTypeDef *huart){

	__UART_RX;
	switch(modbus_stage){

	case Stage_02:
		HAL_UART_Receive_DMA(&huart2, &res01.SlaveAdd , __RES01_L);
		modbus_status = modbus_Rx;
		break;

	case Stage_03:
		HAL_UART_Receive_DMA(&huart2, &res03.SlaveAdd, __RES03_L);
		modbus_status = modbus_Rx;
		break;

	case Stage_0F:
		HAL_UART_Receive_DMA(&huart2, &res0F.SlaveAdd, __RES0F_L);
		modbus_status = modbus_Rx;
		break;

	case Stage_10:
		HAL_UART_Receive_DMA(&huart2, &res06.SlaveAdd, __RES06_L);
		modbus_status = modbus_Rx;
		break;

	default:
		break;


	}


}


void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart){

	__UART_TX;
	switch(modbus_stage){

	case Stage_02:
		// cmd01 reception management
		CRC16_Ptr =  (uint16_t *)&res01.CRC_L;
		if (  *CRC16_Ptr == CRC_CAL(&res01.SlaveAdd,__RES01_BYTE_CRC)){
			__GLED_ON;
			LED_Change(res01.Data);
		}else{__GLED_OFF;}

		// cmd03 Send command
		HAL_UART_Transmit_DMA(&huart2, &cmd03.SlaveAdd , __CMD03_L);
		modbus_stage = Stage_03;
		modbus_status = modbus_Tx;


		break;

	case Stage_03:
		// cmd03 reception management
		CRC16_Ptr =  (uint16_t *)&res03.CRC_L;
		if (  *CRC16_Ptr == CRC_CAL(&res03.SlaveAdd,__RES03_BYTE_CRC)){
			__GLED_ON;
			myc0 = (uint16_t)res03.Data_H << 8 | res03.Data_L ;
		}else{__GLED_OFF;}



		// cmd0F Send command

		if ( GPIOB->IDR & GPIO_IDR_IDR12 ){
			cmd0F_byte |= 0x1;
		}else{ cmd0F_byte &= ~0x1; }

		if ( GPIOB->IDR & GPIO_IDR_IDR13 ){
			cmd0F_byte |= 0x2;
		}else{ cmd0F_byte &= ~0x2; }

		if ( GPIOB->IDR & GPIO_IDR_IDR14 ){
			cmd0F_byte |= 0x4;
		}else{ cmd0F_byte &= ~0x4; }

		if ( GPIOB->IDR & GPIO_IDR_IDR15 ){
			cmd0F_byte |= 0x8;
		}else{ cmd0F_byte &= ~0x8; }


		cmd0F.Data  = cmd0F_byte;

		myCRC16 = CRC_CAL(&cmd0F.SlaveAdd,__CMD0F_BYTE_CRC);
		cmd0F.CRC_L = myCRC16;
		cmd0F.CRC_H = myCRC16>>8;

		HAL_UART_Transmit_DMA(&huart2, &cmd0F.SlaveAdd,__CMD0F_L);
		modbus_status = modbus_Tx;
		modbus_stage = Stage_0F;


		break;

	case Stage_0F:
		// cmd0F reception management
		CRC16_Ptr =  (uint16_t *)&res0F.CRC_L;
		if (  *CRC16_Ptr == CRC_CAL(&res0F.SlaveAdd,__RES0F_BYTE_CRC)){
			__GLED_ON;
		}else{__GLED_OFF;}

		// cmd06 Send command

		cmd06.Data_H = (uint8_t)(ADC1->DR >> 8);
		cmd06.Data_L = (uint8_t)ADC1->DR;

		myCRC16 = CRC_CAL(&cmd06.SlaveAdd,__CMD06_BYTE_CRC);
		cmd06.CRC_L = myCRC16;
		cmd06.CRC_H = myCRC16>>8;

		HAL_UART_Transmit_DMA(&huart2,  &cmd06.SlaveAdd,__CMD06_L);
		modbus_status = modbus_Tx;
		modbus_stage = Stage_10;


		break;

	case Stage_10:
		// cmd06 reception management
		CRC16_Ptr =  (uint16_t *)&res06.CRC_L;
		if (  *CRC16_Ptr == CRC_CAL(&res06.SlaveAdd,__RES06_BYTE_CRC)){
			__GLED_ON;
		}else{__GLED_OFF;}

		modbus_status = modbus_idle;




		break;

	default:
		break;


	}

}
