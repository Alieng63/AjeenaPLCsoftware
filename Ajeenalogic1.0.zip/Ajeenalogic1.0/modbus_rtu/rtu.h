#pragma once


#include "main.h"



//feedback message number of CRC bytes
#define __RES01_BYTE_CRC 4
#define __RES03_BYTE_CRC 5
#define __RES0F_BYTE_CRC 6
#define __RES06_BYTE_CRC 6

//feedback message length
#define __RES01_L 6
#define __RES03_L 7
#define __RES0F_L 8
#define __RES06_L 8

//sent message number of CRC bytes
#define __cmd01_BYTE_CRC 6
#define __CMD03_BYTE_CRC 6
#define __CMD0F_BYTE_CRC 8
#define __CMD06_BYTE_CRC 6


//sent message length
#define __CMD01_L 8
#define __CMD03_L 8
#define __CMD0F_L 10
#define __CMD06_L 8

// Structure Types for sent  messages

typedef struct{
	uint8_t SlaveAdd;
	uint8_t CMD;
	uint8_t Add_H;
	uint8_t Add_L;
	uint8_t NOP_H;
	uint8_t NOP_L;
	uint8_t CRC_L;
	uint8_t CRC_H;
}cmd01_typedef;

typedef struct{
	uint8_t SlaveAdd;
	uint8_t CMD;
	uint8_t Add_H;
	uint8_t Add_L;
	uint8_t NOP_H;
	uint8_t NOP_L;
	uint8_t CRC_L;
	uint8_t CRC_H;
}cmd03_typedef;

typedef struct{
	uint8_t SlaveAdd;
	uint8_t CMD;
	uint8_t Add_H;
	uint8_t Add_L;
	uint8_t NOP_H;
	uint8_t NOP_L;
	uint8_t CNT;
	uint8_t Data;
	uint8_t CRC_L;
	uint8_t CRC_H;
}cmd0F_typedef;

typedef struct{
	uint8_t SlaveAdd;
	uint8_t CMD;
	uint8_t Add_H;
	uint8_t Add_L;
	uint8_t Data_H;
	uint8_t Data_L;
	uint8_t CRC_L;
	uint8_t CRC_H;
}cmd06_typedef;

// Structure Types for feedback  messages

typedef struct{
	uint8_t SlaveAdd;
	uint8_t CMD;
	uint8_t ByteCNT;
	uint8_t Data;
	uint8_t CRC_L;
	uint8_t CRC_H;
}res01_typedef;


typedef struct{
	uint8_t SlaveAdd;
	uint8_t CMD;
	uint8_t ByteCNT;
	uint8_t Data_H;
	uint8_t Data_L;
	uint8_t CRC_L;
	uint8_t CRC_H;
}res03_typedef;

typedef struct{
	uint8_t SlaveAdd;
	uint8_t CMD;
	uint8_t Add_H;
	uint8_t Add_L;
	uint8_t NOP_H;
	uint8_t NOP_L;
	uint8_t CRC_L;
	uint8_t CRC_H;
}res0F_typedef;

typedef struct{
	uint8_t SlaveAdd;
	uint8_t CMD;
	uint8_t Add_H;
	uint8_t Add_L;
	uint8_t Data_H;
	uint8_t Data_L;
	uint8_t CRC_L;
	uint8_t CRC_H;
}res06_typedef;

//structure for feedback messages
extern res01_typedef res01;
extern res03_typedef res03;
extern res0F_typedef res0F;
extern res06_typedef res06;;

//Structure definition for sent messages
extern cmd01_typedef cmd01;
extern cmd03_typedef cmd03;
extern cmd0F_typedef cmd0F;
extern cmd06_typedef cmd06;


void RTU_Init(void);
uint16_t CRC_CAL(uint8_t * byte,uint8_t num);






