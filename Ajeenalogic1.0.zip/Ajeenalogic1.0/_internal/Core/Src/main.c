#include "stm32f1xx.h"

#include "main.h"

#include <stdbool.h>


bool m[1000];

uint16_t D[1000];

uint32_t DD[500];

#define MAX_TIMERS 100

typedef struct {

uint32_t preset;   // in 100 ms units

uint32_t value;

bool enable;

bool done;

} PLC_Timer;

PLC_Timer t[MAX_TIMERS];

void update_all_timers(void)

{

for (int i = 0; i < MAX_TIMERS; i++) {

if (t[i].enable) {

if (t[i].value < t[i].preset){

t[i].value++;}

else{

t[i].done = 1;}

} else {

t[i].value = 0;

t[i].done = 0;

}

}

}





PLC_Timer tt[50];

void update_all_timersh(void)

{

for (int i = 0; i < 50; i++) {

if (tt[i].enable) {

if (tt[i].value < tt[i].preset){

tt[i].value++;}

else{

tt[i].done = 1;}

} else {

tt[i].value = 0;

tt[i].done = 0;

}

}

}







uint32_t year=25; 
uint32_t month=1; 
uint32_t date=25; 
uint32_t day=25; 
uint32_t hour=2; 
uint32_t minte=25; 
uint32_t sec=25; 


    uint32_t timerP2=1000;
uint32_t timerP3=100;
uint32_t timerP4=60000;
TIM_HandleTypeDef htim2;
TIM_HandleTypeDef htim3;
TIM_HandleTypeDef htim4;
void changeval(void){

}

    // 
    #define x1 !HAL_GPIO_ReadPin(GPIOA, GPIO_PIN_1)
#define x2 !HAL_GPIO_ReadPin(GPIOA, GPIO_PIN_2)

//set
//reset

void updatePLCLogic() {
    if ( (x1)) {
    m[1]=true;}
    if ( (x2)) {
    m[1]=false;}
}
RTC_HandleTypeDef hrtc;
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_RTC_Init(void);
static void MX_TIM2_Init(void);
static void MX_TIM3_Init(void);
static void MX_TIM4_Init(void);
int main(void) {
HAL_Init();
SystemClock_Config();
MX_GPIO_Init();
MX_RTC_Init();
MX_TIM2_Init();
MX_TIM3_Init();
MX_TIM4_Init();
HAL_TIM_Base_Start_IT(&htim2);
HAL_TIM_Base_Start_IT(&htim3);
HAL_TIM_Base_Start_IT(&htim4);
__HAL_TIM_SET_COUNTER(&htim2, 0);
__HAL_TIM_SET_COUNTER(&htim3, 0);
__HAL_TIM_SET_COUNTER(&htim4, 0);
HAL_TIM_Base_Stop(&htim4);
changeval();


while (1) {
       updatePLCLogic();
HAL_Delay(10); // Small delay to reduce CPU load 
}
}

static void MX_GPIO_Init(void){
GPIO_InitTypeDef GPIO_InitStruct = {0};
 __HAL_RCC_GPIOA_CLK_ENABLE();
 __HAL_RCC_GPIOB_CLK_ENABLE();
// Additional difunitions
GPIO_InitStruct.Pin = GPIO_PIN_1;
GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
GPIO_InitStruct.Pull = GPIO_PULLUP;
HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);
GPIO_InitStruct.Pin = GPIO_PIN_2;
GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
GPIO_InitStruct.Pull = GPIO_PULLUP;
HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

}
void SystemClock_Config(void) {
RCC_OscInitTypeDef RCC_OscInitStruct = {0};
RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
RCC_OscInitStruct.HSEState = RCC_HSE_ON;
RCC_OscInitStruct.HSEPredivValue = RCC_HSE_PREDIV_DIV1;
RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
RCC_OscInitStruct.PLL.PLLMUL = RCC_PLL_MUL9;
HAL_RCC_OscConfig(&RCC_OscInitStruct);

RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK|RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;
HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2);
}

// timers interrupts
void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim) {
if (htim == &htim2) {
update_all_timers();
}
if (htim == &htim3) {
update_all_timersh();
}
}

static void MX_RTC_Init(void) {
RTC_TimeTypeDef sTime = {0};
RTC_DateTypeDef DateToUpdate = {0};
 RTC_AlarmTypeDef sAlarm = {0};
hrtc.Instance = RTC;
hrtc.Init.AsynchPrediv = RTC_AUTO_1_SECOND;
hrtc.Init.OutPut = RTC_OUTPUTSOURCE_ALARM;
if (HAL_RTC_Init(&hrtc) != HAL_OK) {}
sTime.Hours = hour;
sTime.Minutes = minte;
sTime.Seconds = sec;
if (HAL_RTC_SetTime(&hrtc, &sTime, RTC_FORMAT_BIN) != HAL_OK){}
DateToUpdate.WeekDay = day;
DateToUpdate.Month = month;
DateToUpdate.Date = date;
DateToUpdate.Year = year;
if (HAL_RTC_SetDate(&hrtc, &DateToUpdate, RTC_FORMAT_BIN) != HAL_OK){}
sAlarm.AlarmTime.Hours =1;
sAlarm.AlarmTime.Minutes = 2;
sAlarm.AlarmTime.Seconds = 3;
sAlarm.Alarm = RTC_ALARM_A;
HAL_NVIC_SetPriority(RTC_Alarm_IRQn, 0, 0);
HAL_NVIC_EnableIRQ(RTC_Alarm_IRQn);
if (HAL_RTC_SetAlarm_IT(&hrtc, &sAlarm, RTC_FORMAT_BIN) != HAL_OK){}
}
static void MX_TIM2_Init(void){
htim2.Instance = TIM2;
htim2.Init.Prescaler = 7200-1;
htim2.Init.CounterMode = TIM_COUNTERMODE_UP;
htim2.Init.Period = timerP2;
htim2.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
htim2.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
HAL_TIM_Base_Init(&htim2);
HAL_NVIC_SetPriority(TIM2_IRQn, 0, 0);
HAL_NVIC_EnableIRQ(TIM2_IRQn);
}
static void MX_TIM3_Init(void){
htim3.Instance = TIM3;
htim3.Init.Prescaler = 7200-1;
htim3.Init.CounterMode = TIM_COUNTERMODE_UP;
htim3.Init.Period = timerP3;
htim3.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
htim3.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
HAL_TIM_Base_Init(&htim3);
HAL_NVIC_SetPriority(TIM3_IRQn, 0, 0);
HAL_NVIC_EnableIRQ(TIM3_IRQn);
}
static void MX_TIM4_Init(void){
htim4.Instance = TIM4;
htim4.Init.Prescaler = 7200-1;
htim4.Init.CounterMode = TIM_COUNTERMODE_UP;
htim4.Init.Period = timerP4;
htim4.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
htim4.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
HAL_TIM_Base_Init(&htim4);
HAL_NVIC_SetPriority(TIM4_IRQn, 0, 0);
HAL_NVIC_EnableIRQ(TIM4_IRQn);
}












